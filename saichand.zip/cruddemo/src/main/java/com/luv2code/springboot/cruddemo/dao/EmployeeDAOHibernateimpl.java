package com.luv2code.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.luv2code.springboot.cruddemo.entity.Employee;


@Repository
public class EmployeeDAOHibernateimpl implements EmployeeDAO {

	//Step 1: Define field for entity manager
	private EntityManager entityManager;
	
	//Step 2: Define or set-up Constructor injection
	@Autowired
	public EmployeeDAOHibernateimpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
		
	}
	
	@Override
	@Transactional
	public List<Employee> findAll() {
		//Step:1 - get the current hibernate session that was created by entity manager
		Session currentSession = entityManager.unwrap(Session.class);
			//entityManager.unwrap - used to get current session from entityManager
		//Step:2 - create the query
		Query<Employee> theQuery = currentSession.createQuery("from employee",Employee.class);
		//Step:3 - execute the query and get result list
		List<Employee> employees = theQuery.getResultList();
		//Step:4 - return the results
		return employees;
	}

}
